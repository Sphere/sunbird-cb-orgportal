export namespace NSWatOfficer {
  export interface IOfficerGroup {
    officerName: string
    position: string
    positionDescription: string
  }
}

import { AutocompleteDirective } from './autocomplete.directive'

describe('AutocompleteDirective', () => {
  it('should create an instance', () => {
    const directive = new AutocompleteDirective()
    expect(directive).toBeTruthy()
  })
})

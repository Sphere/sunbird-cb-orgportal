import { AutocompleteContentDirective } from './autocomplete-content.directive'

describe('AutocompleteContentDirective', () => {
  it('should create an instance', () => {
    const directive = new AutocompleteContentDirective()
    expect(directive).toBeTruthy()
  })
})

export interface IUserDetails {
  UserName: string
  Location: string
  ImageUrl: string
  RegisteredDate: string
}

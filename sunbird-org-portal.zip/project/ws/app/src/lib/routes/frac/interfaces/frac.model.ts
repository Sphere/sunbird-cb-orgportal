export interface IFrac {
  iframeId: string
  title: string
  containerStyle: string
  containerClass: string
  iframeSrc: string
}

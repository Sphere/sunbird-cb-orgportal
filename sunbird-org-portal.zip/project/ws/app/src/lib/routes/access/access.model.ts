
export interface IAccessLeftMenu {
  name: string
  key: string
  render: boolean
  enabled: boolean
  routerLink: string
}

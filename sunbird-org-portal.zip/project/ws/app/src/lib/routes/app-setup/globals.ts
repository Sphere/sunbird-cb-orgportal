import { Injectable } from '@angular/core'

@Injectable()
export class Globals {
  firstTimeSetupDone = false

}

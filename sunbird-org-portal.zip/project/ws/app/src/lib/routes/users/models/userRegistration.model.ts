export interface IResponseAllSources {
  licenseExpiredOn: number,
  progressProvided: boolean,
  registrationUrl: string,
  source: string
}

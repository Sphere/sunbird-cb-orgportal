export enum WorkAllocationStatus {
  Published = 'Published',
  Export = 'Export',
  Draft = 'Draft',
}

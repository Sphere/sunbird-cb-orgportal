export interface IPrintCount {
  heading: string
  count: number
}

export interface IWidgetBtnContentFeedbackV2 {
  identifier: string
  name: string
  isDisabled?: boolean
}

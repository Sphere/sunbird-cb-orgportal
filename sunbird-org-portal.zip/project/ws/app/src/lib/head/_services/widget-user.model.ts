export interface IUserGroupDetails {
  group_id: number
  friendly_name: string
  description: string
}

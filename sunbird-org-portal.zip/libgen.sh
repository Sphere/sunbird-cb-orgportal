# widgets=("")
# for widget in $widgets
# do
#   ng g m $widget --project=@sunbird-cb/collection
#   ng g c $widget --project=@sunbird-cb/collection --entryComponent=true
# done

# directives=("")
# for directive in $directives
# do
#   ng g m directives/$directive --project=@sunbird-cb/utils
#   ng g d directives/$directive/$directive --project=@sunbird-cb/utils --export=true --flat --lintFix=true
# done

# pipes=("")
# for pipe in $pipes
# do
#   ng g m pipes/$pipe --project=@sunbird-cb/utils
#   ng g p pipes/$pipe/$pipe --project=@sunbird-cb/utils --export=true --flat --lintFix=true
# done

import * as i0 from '@angular/core';
import { Type, AfterViewInit, ComponentFactoryResolver, ViewContainerRef, ComponentRef, OnChanges, OnInit, ModuleWithProviders } from '@angular/core';
import { SafeStyle, DomSanitizer } from '@angular/platform-browser';
import { Omit as Omit$1 } from 'lodash';
import { LoggerService } from '@sunbird-cb/utils-v2';
import * as i7 from '@angular/common';
import * as i8 from '@angular/material/button';
import * as i9 from '@angular/material/icon';
import * as i10 from '@angular/material/card';

type TUrl = undefined | 'none' | 'back' | string;
declare namespace NsWidgetResolver {
    type UnitPermissionPrimitive = undefined | null | string;
    interface IUnitPermissionObject {
        all: UnitPermissionPrimitive | string[];
        none: UnitPermissionPrimitive | string[];
        some: UnitPermissionPrimitive | string[];
    }
    type UnitPermission = UnitPermissionPrimitive | string[] | IUnitPermissionObject | Pick<IUnitPermissionObject, 'all'> | Pick<IUnitPermissionObject, 'none'> | Pick<IUnitPermissionObject, 'some'> | Exclude<IUnitPermissionObject, 'all'> | Exclude<IUnitPermissionObject, 'none'> | Exclude<IUnitPermissionObject, 'some'>;
    interface IPermissions {
        enabled: boolean;
        available: boolean;
        roles?: UnitPermission;
        features?: UnitPermission;
        groups?: UnitPermission;
    }
    interface IBaseConfig {
        widgetType: string;
        widgetSubType: string;
    }
    interface IRegistrationConfig extends IBaseConfig {
        component: Type<IWidgetData<any>>;
    }
    interface IRegistrationsPermissionConfig extends IBaseConfig {
        widgetPermission?: IPermissions;
    }
    interface IRenderConfigWithTypedData<T> extends IRegistrationsPermissionConfig {
        widgetData: T;
        widgetInstanceId?: string;
        widgetHostClass?: string;
        widgetHostStyle?: {
            [key: string]: string;
        };
    }
    type IRenderConfigWithAnyData = IRenderConfigWithTypedData<any>;
    interface IWidgetData<T> extends Omit$1<IRenderConfigWithTypedData<T>, 'widgetPermission' | 'widgetHostStyle'> {
        widgetSafeStyle?: SafeStyle;
        updateBaseComponent: (widgetType: string, widgetSubType: string, widgetInstanceId?: string, widgetHostClass?: string, widgetSafeStyle?: SafeStyle) => void;
    }
    interface ITitle {
        title: string;
        url: TUrl;
        icon?: string;
    }
}

type TWidgetBase = Omit<NsWidgetResolver.IWidgetData<any>, 'widgetData'>;
declare class WidgetBaseComponent implements TWidgetBase, AfterViewInit {
    widgetType: string;
    widgetSubType: string;
    widgetHostClass?: string;
    widgetInstanceId?: string;
    widgetSafeStyle?: SafeStyle;
    className?: string;
    updateBaseComponent(widgetType: string, widgetSubType: string, widgetInstanceId?: string, widgetHostClass?: string, widgetSafeStyle?: SafeStyle): void;
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<WidgetBaseComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<WidgetBaseComponent, "sb-ui-resolver-base", never, { "widgetType": { "alias": "widgetType"; "required": false; }; "widgetSubType": { "alias": "widgetSubType"; "required": false; }; "widgetHostClass": { "alias": "widgetHostClass"; "required": false; }; "widgetInstanceId": { "alias": "widgetInstanceId"; "required": false; }; "widgetSafeStyle": { "alias": "widgetSafeStyle"; "required": false; }; "className": { "alias": "className"; "required": false; }; }, {}, never, never, false, never>;
}

declare class SbUiResolverService {
    private domSanitizer;
    private componentFactoryResolver;
    private globalConfig;
    private scopedConfig;
    private roles;
    private groups;
    private restrictedFeatures;
    isInitialized: boolean;
    constructor(domSanitizer: DomSanitizer, componentFactoryResolver: ComponentFactoryResolver, globalConfig: null | NsWidgetResolver.IRegistrationConfig[], scopedConfig: null | NsWidgetResolver.IRegistrationConfig[]);
    private availableRegisteredWidgets;
    private restrictedWidgetKeys;
    static getWidgetKey(config: NsWidgetResolver.IBaseConfig): string;
    initialize(restrictedWidgetKeys: Set<string> | null, roles: Set<string> | null, groups: Set<string> | null, restrictedFeatures: Set<string> | null): void;
    resolveWidget(receivedConfig: NsWidgetResolver.IRenderConfigWithAnyData, containerRef: ViewContainerRef): ComponentRef<any> | null;
    private widgetResolved;
    static ɵfac: i0.ɵɵFactoryDeclaration<SbUiResolverService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SbUiResolverService>;
}

declare class SbUiResolverDirective implements OnChanges {
    private viewContainerRef;
    private widgetResolverSvc;
    private logger;
    sbUiResolverWidget: NsWidgetResolver.IRenderConfigWithAnyData | null;
    constructor(viewContainerRef: ViewContainerRef, widgetResolverSvc: SbUiResolverService, logger: LoggerService);
    ngOnChanges(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SbUiResolverDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SbUiResolverDirective, "[sbUiResolverWidget]", never, { "sbUiResolverWidget": { "alias": "sbUiResolverWidget"; "required": false; }; }, {}, never, never, false, never>;
}

declare class RestrictedComponent extends WidgetBaseComponent implements OnInit, NsWidgetResolver.IWidgetData<any> {
    widgetData: any;
    showData: boolean;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RestrictedComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RestrictedComponent, "sb-ui-resolver-restricted", never, { "widgetData": { "alias": "widgetData"; "required": false; }; }, {}, never, never, false, never>;
}

declare class InvalidRegistrationComponent extends WidgetBaseComponent implements OnInit, NsWidgetResolver.IWidgetData<any> {
    widgetData: any;
    showData: boolean;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<InvalidRegistrationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<InvalidRegistrationComponent, "sb-ui-resolver-invalid-registration", never, { "widgetData": { "alias": "widgetData"; "required": false; }; }, {}, never, never, false, never>;
}

declare class InvalidPermissionComponent extends WidgetBaseComponent implements OnInit, NsWidgetResolver.IWidgetData<any> {
    widgetType: string;
    widgetSubType: string;
    widgetInstanceId?: string;
    widgetData: any;
    showData: boolean;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<InvalidPermissionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<InvalidPermissionComponent, "sb-ui-resolver-invalid-permission", never, { "widgetType": { "alias": "widgetType"; "required": false; }; "widgetSubType": { "alias": "widgetSubType"; "required": false; }; "widgetInstanceId": { "alias": "widgetInstanceId"; "required": false; }; "widgetData": { "alias": "widgetData"; "required": false; }; }, {}, never, never, false, never>;
}

declare class UnresolvedComponent extends WidgetBaseComponent implements OnInit, NsWidgetResolver.IWidgetData<any> {
    widgetData: any;
    showData: boolean;
    previewMode: boolean;
    searchArray: string[];
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UnresolvedComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UnresolvedComponent, "sb-ui-resolver-unresolved", never, { "widgetData": { "alias": "widgetData"; "required": false; }; }, {}, never, never, false, never>;
}

declare class SbUiResolverModule {
    static forRoot(config: NsWidgetResolver.IRegistrationConfig[]): ModuleWithProviders<SbUiResolverModule>;
    static forChild(config: NsWidgetResolver.IRegistrationConfig[]): ModuleWithProviders<SbUiResolverModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SbUiResolverModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SbUiResolverModule, [typeof WidgetBaseComponent, typeof SbUiResolverDirective, typeof RestrictedComponent, typeof InvalidRegistrationComponent, typeof InvalidPermissionComponent, typeof UnresolvedComponent], [typeof i7.CommonModule, typeof i8.MatButtonModule, typeof i9.MatIconModule, typeof i10.MatCardModule], [typeof SbUiResolverDirective, typeof WidgetBaseComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SbUiResolverModule>;
}

declare function hasUnitPermission(requiredPermission: NsWidgetResolver.UnitPermission, matchAgainst?: Set<string> | string[] | string | null | undefined, isRestrictive?: boolean): boolean;
declare function hasPermissions(requiredPermission?: NsWidgetResolver.IPermissions, availableRoles?: Set<string> | string | string[] | null | undefined, availableGroups?: Set<string> | string | string[] | null | undefined, restrictedFeatures?: Set<string> | string | string[] | null | undefined): boolean;

export { NsWidgetResolver, SbUiResolverDirective, SbUiResolverModule, SbUiResolverService, WidgetBaseComponent, hasPermissions, hasUnitPermission };
//# sourceMappingURL=index.d.ts.map

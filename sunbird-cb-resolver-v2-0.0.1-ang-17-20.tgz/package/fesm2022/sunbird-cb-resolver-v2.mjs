import * as i0 from '@angular/core';
import { InjectionToken, Input, HostBinding, Component, Inject, Injectable, Directive, NgModule } from '@angular/core';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i2 from '@angular/material/button';
import { MatButtonModule } from '@angular/material/button';
import * as i3 from '@angular/material/icon';
import { MatIconModule } from '@angular/material/icon';
import * as i4 from '@angular/material/card';
import { MatCardModule } from '@angular/material/card';
import * as i1$1 from '@angular/platform-browser';
import * as i2$1 from '@sunbird-cb/utils-v2';

const WIDGET_RESOLVER_GLOBAL_CONFIG = new InjectionToken('Global Registration Configuration for Widget Resolvers');
const WIDGET_RESOLVER_SCOPED_CONFIG = new InjectionToken('Scoped Registration Configuration for Widget Resolvers');

function isStringArray(strArr) {
    return Array.isArray(strArr) && strArr.every(u => typeof u === 'string');
}
function isCheckRequired(requiredPermission) {
    if (requiredPermission === undefined ||
        requiredPermission === null ||
        requiredPermission === '' ||
        (Array.isArray(requiredPermission) && requiredPermission.length === 0)) {
        return false;
    }
    return true;
}
function flipBoolean(value, flip = false) {
    return flip ? !value : value;
}
function permissionTest(testFor, requiredPermission, matchAgainst, isRestrictive = false) {
    if (!isCheckRequired(requiredPermission)) {
        return true;
    }
    if (typeof requiredPermission === 'string') {
        switch (testFor) {
            case 'all':
            case 'some':
                return flipBoolean(matchAgainst.has(requiredPermission), isRestrictive);
            case 'none':
                return flipBoolean(!matchAgainst.has(requiredPermission), isRestrictive);
        }
    }
    if (Array.isArray(requiredPermission)) {
        const matcher = (u) => typeof u === 'string' && flipBoolean(matchAgainst.has(u), isRestrictive);
        switch (testFor) {
            case 'all':
                return requiredPermission.every(matcher);
            case 'some':
                return requiredPermission.some(matcher);
            case 'none':
                return !requiredPermission.every(matcher);
        }
    }
    return false;
}
function hasUnitPermission(requiredPermission, matchAgainst, isRestrictive = false) {
    if (!isCheckRequired(requiredPermission)) {
        return true;
    }
    const accessValues = matchAgainst instanceof Set
        ? matchAgainst
        : Array.isArray(matchAgainst) && isStringArray(matchAgainst)
            ? new Set(matchAgainst)
            : typeof matchAgainst === 'string'
                ? new Set([matchAgainst])
                : new Set();
    if (typeof requiredPermission === 'object' && requiredPermission !== null) {
        if (Array.isArray(requiredPermission)) {
            return permissionTest('all', requiredPermission, accessValues, isRestrictive);
        }
        return (permissionTest('all', 'all' in requiredPermission ? requiredPermission.all : null, accessValues, isRestrictive) &&
            permissionTest('some', 'some' in requiredPermission ? requiredPermission.some : null, accessValues, isRestrictive) &&
            permissionTest('none', 'none' in requiredPermission ? requiredPermission.none : null, accessValues, isRestrictive));
    }
    return false;
}
function hasPermissions(requiredPermission, availableRoles, availableGroups, restrictedFeatures) {
    if (!requiredPermission) {
        return true;
    }
    if (!requiredPermission.available || !requiredPermission.enabled) {
        return false;
    }
    return (hasUnitPermission(requiredPermission.groups, availableGroups) &&
        hasUnitPermission(requiredPermission.roles, availableRoles) &&
        hasUnitPermission(requiredPermission.features, restrictedFeatures, true));
}

class WidgetBaseComponent {
    constructor() {
        this.widgetType = '';
        this.widgetSubType = '';
    }
    updateBaseComponent(widgetType, widgetSubType, widgetInstanceId, widgetHostClass, widgetSafeStyle) {
        this.widgetType = widgetType;
        this.widgetSubType = widgetSubType;
        this.widgetInstanceId = widgetInstanceId;
        this.widgetHostClass = widgetHostClass;
        this.widgetSafeStyle = widgetSafeStyle;
        if (this.widgetHostClass) {
            this.className = `${this.className} ${this.widgetHostClass}`;
        }
    }
    ngAfterViewInit() {
        const hash = window.location.hash ? window.location.hash.split('#')[1] : '';
        if (hash && !isNaN(hash) && hash === this.widgetInstanceId) {
            setTimeout(() => {
                const element = document.getElementById(this.widgetInstanceId || '');
                if (element) {
                    element.scrollIntoView();
                }
            }, 200);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: WidgetBaseComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.16", type: WidgetBaseComponent, isStandalone: false, selector: "sb-ui-resolver-base", inputs: { widgetType: "widgetType", widgetSubType: "widgetSubType", widgetHostClass: "widgetHostClass", widgetInstanceId: "widgetInstanceId", widgetSafeStyle: "widgetSafeStyle", className: "className" }, host: { properties: { "id": "this.widgetInstanceId", "style": "this.widgetSafeStyle", "class": "this.className" } }, ngImport: i0, template: 'Base Component', isInline: true }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: WidgetBaseComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'sb-ui-resolver-base',
                    template: 'Base Component',
                    standalone: false
                }]
        }], propDecorators: { widgetType: [{
                type: Input
            }], widgetSubType: [{
                type: Input
            }], widgetHostClass: [{
                type: Input
            }], widgetInstanceId: [{
                type: Input
            }, {
                type: HostBinding,
                args: ['id']
            }], widgetSafeStyle: [{
                type: Input
            }, {
                type: HostBinding,
                args: ['style']
            }], className: [{
                type: Input
            }, {
                type: HostBinding,
                args: ['class']
            }] } });

class RestrictedComponent extends WidgetBaseComponent {
    constructor() {
        super(...arguments);
        this.showData = true;
    }
    ngOnInit() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: RestrictedComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.16", type: RestrictedComponent, isStandalone: false, selector: "sb-ui-resolver-restricted", inputs: { widgetData: "widgetData" }, usesInheritance: true, ngImport: i0, template: "<mat-card class=\"margin-m\">\n  <mat-card-header>\n    <div mat-card-avatar class=\"mat-card-avatar-override\">\n      <mat-icon color=\"warn\">report_problem</mat-icon>\n    </div>\n    <mat-card-title>\n      <ng-container i18n>\n        Error as Restricted Widget\n      </ng-container>\n    </mat-card-title>\n  </mat-card-header>\n  <div class=\"flex flex-wrap flex-between\">\n    <div>\n      <div class=\"margin-top-s\">\n        <span class=\"mat-body-2 font-bold\" i18n>\n          Widget Type :\n        </span>\n        {{ widgetType }}\n      </div>\n      <div class=\"margin-top-s\">\n        <span class=\"mat-body-2 font-bold\" i18n>\n          Widget Sub Type :\n        </span>\n        {{ widgetSubType }}\n      </div>\n    </div>\n    <div>\n      <ng-container *ngIf=\"widgetData\">\n        <button mat-raised-button class=\"margin-top-m\" color=\"primary\" *ngIf=\"!showData\" (click)=\"showData = true\">\n          <ng-container i18n>See Details</ng-container>\n          <mat-icon>arrow_drop_down</mat-icon>\n        </button>\n        <button mat-raised-button class=\"margin-top-m\" color=\"primary\" *ngIf=\"showData\" (click)=\"showData = false\">\n          <ng-container i18n>Hide Details</ng-container>\n          <mat-icon>arrow_drop_up</mat-icon>\n        </button>\n      </ng-container>\n    </div>\n  </div>\n  <ng-container *ngIf=\"widgetData\">\n    <pre *ngIf=\"showData\" class=\"margin-top-s \"><span i18n class=\"mat-body-2 font-bold\">Widget Data :</span>\n{{ widgetData | json }}\n    </pre>\n  </ng-container>\n</mat-card>", styles: [".mat-card-avatar-override{height:24px!important;width:24px!important}\n"], dependencies: [{ kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i2.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: i3.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "component", type: i4.MatCard, selector: "mat-card", inputs: ["appearance"], exportAs: ["matCard"] }, { kind: "directive", type: i4.MatCardAvatar, selector: "[mat-card-avatar], [matCardAvatar]" }, { kind: "component", type: i4.MatCardHeader, selector: "mat-card-header" }, { kind: "directive", type: i4.MatCardTitle, selector: "mat-card-title, [mat-card-title], [matCardTitle]" }, { kind: "pipe", type: i1.JsonPipe, name: "json" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: RestrictedComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sb-ui-resolver-restricted', standalone: false, template: "<mat-card class=\"margin-m\">\n  <mat-card-header>\n    <div mat-card-avatar class=\"mat-card-avatar-override\">\n      <mat-icon color=\"warn\">report_problem</mat-icon>\n    </div>\n    <mat-card-title>\n      <ng-container i18n>\n        Error as Restricted Widget\n      </ng-container>\n    </mat-card-title>\n  </mat-card-header>\n  <div class=\"flex flex-wrap flex-between\">\n    <div>\n      <div class=\"margin-top-s\">\n        <span class=\"mat-body-2 font-bold\" i18n>\n          Widget Type :\n        </span>\n        {{ widgetType }}\n      </div>\n      <div class=\"margin-top-s\">\n        <span class=\"mat-body-2 font-bold\" i18n>\n          Widget Sub Type :\n        </span>\n        {{ widgetSubType }}\n      </div>\n    </div>\n    <div>\n      <ng-container *ngIf=\"widgetData\">\n        <button mat-raised-button class=\"margin-top-m\" color=\"primary\" *ngIf=\"!showData\" (click)=\"showData = true\">\n          <ng-container i18n>See Details</ng-container>\n          <mat-icon>arrow_drop_down</mat-icon>\n        </button>\n        <button mat-raised-button class=\"margin-top-m\" color=\"primary\" *ngIf=\"showData\" (click)=\"showData = false\">\n          <ng-container i18n>Hide Details</ng-container>\n          <mat-icon>arrow_drop_up</mat-icon>\n        </button>\n      </ng-container>\n    </div>\n  </div>\n  <ng-container *ngIf=\"widgetData\">\n    <pre *ngIf=\"showData\" class=\"margin-top-s \"><span i18n class=\"mat-body-2 font-bold\">Widget Data :</span>\n{{ widgetData | json }}\n    </pre>\n  </ng-container>\n</mat-card>", styles: [".mat-card-avatar-override{height:24px!important;width:24px!important}\n"] }]
        }], propDecorators: { widgetData: [{
                type: Input
            }] } });

class InvalidRegistrationComponent extends WidgetBaseComponent {
    constructor() {
        super(...arguments);
        this.showData = true;
    }
    ngOnInit() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: InvalidRegistrationComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.16", type: InvalidRegistrationComponent, isStandalone: false, selector: "sb-ui-resolver-invalid-registration", inputs: { widgetData: "widgetData" }, usesInheritance: true, ngImport: i0, template: "<mat-card class=\"margin-m\">\n  <mat-card-header>\n    <div mat-card-avatar class=\"mat-card-avatar-override\">\n      <mat-icon color=\"warn\">report_problem</mat-icon>\n    </div>\n    <mat-card-title>\n      <ng-container i18n>\n        Error as Invalid Registration for Widget\n      </ng-container>\n    </mat-card-title>\n  </mat-card-header>\n  <div class=\"flex flex-wrap flex-between\">\n    <div>\n      <div class=\"margin-top-s\">\n        <span class=\"mat-body-2 font-bold\" i18n>\n          Widget Type :\n        </span>\n        {{ widgetType }}\n      </div>\n      <div class=\"margin-top-s\">\n        <span class=\"mat-body-2 font-bold\" i18n>\n          Widget Sub Type :\n        </span>\n        {{ widgetSubType }}\n      </div>\n    </div>\n    <div>\n      <ng-container *ngIf=\"widgetData\">\n        <button mat-raised-button class=\"margin-top-m\" color=\"primary\" *ngIf=\"!showData\" (click)=\"showData = true\">\n          <ng-container i18n>See Details</ng-container>\n          <mat-icon>arrow_drop_down</mat-icon>\n        </button>\n        <button mat-raised-button class=\"margin-top-m\" color=\"primary\" *ngIf=\"showData\" (click)=\"showData = false\">\n          <ng-container i18n>Hide Details</ng-container>\n          <mat-icon>arrow_drop_up</mat-icon>\n        </button>\n      </ng-container>\n    </div>\n  </div>\n  <ng-container *ngIf=\"widgetData\">\n    <pre *ngIf=\"showData\" class=\"margin-top-s \"><span i18n class=\"mat-body-2 font-bold\">Widget Data :</span>\n{{ widgetData | json }}\n    </pre>\n  </ng-container>\n</mat-card>", styles: [".mat-card-avatar-override{height:24px!important;width:24px!important}\n"], dependencies: [{ kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i2.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: i3.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "component", type: i4.MatCard, selector: "mat-card", inputs: ["appearance"], exportAs: ["matCard"] }, { kind: "directive", type: i4.MatCardAvatar, selector: "[mat-card-avatar], [matCardAvatar]" }, { kind: "component", type: i4.MatCardHeader, selector: "mat-card-header" }, { kind: "directive", type: i4.MatCardTitle, selector: "mat-card-title, [mat-card-title], [matCardTitle]" }, { kind: "pipe", type: i1.JsonPipe, name: "json" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: InvalidRegistrationComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sb-ui-resolver-invalid-registration', standalone: false, template: "<mat-card class=\"margin-m\">\n  <mat-card-header>\n    <div mat-card-avatar class=\"mat-card-avatar-override\">\n      <mat-icon color=\"warn\">report_problem</mat-icon>\n    </div>\n    <mat-card-title>\n      <ng-container i18n>\n        Error as Invalid Registration for Widget\n      </ng-container>\n    </mat-card-title>\n  </mat-card-header>\n  <div class=\"flex flex-wrap flex-between\">\n    <div>\n      <div class=\"margin-top-s\">\n        <span class=\"mat-body-2 font-bold\" i18n>\n          Widget Type :\n        </span>\n        {{ widgetType }}\n      </div>\n      <div class=\"margin-top-s\">\n        <span class=\"mat-body-2 font-bold\" i18n>\n          Widget Sub Type :\n        </span>\n        {{ widgetSubType }}\n      </div>\n    </div>\n    <div>\n      <ng-container *ngIf=\"widgetData\">\n        <button mat-raised-button class=\"margin-top-m\" color=\"primary\" *ngIf=\"!showData\" (click)=\"showData = true\">\n          <ng-container i18n>See Details</ng-container>\n          <mat-icon>arrow_drop_down</mat-icon>\n        </button>\n        <button mat-raised-button class=\"margin-top-m\" color=\"primary\" *ngIf=\"showData\" (click)=\"showData = false\">\n          <ng-container i18n>Hide Details</ng-container>\n          <mat-icon>arrow_drop_up</mat-icon>\n        </button>\n      </ng-container>\n    </div>\n  </div>\n  <ng-container *ngIf=\"widgetData\">\n    <pre *ngIf=\"showData\" class=\"margin-top-s \"><span i18n class=\"mat-body-2 font-bold\">Widget Data :</span>\n{{ widgetData | json }}\n    </pre>\n  </ng-container>\n</mat-card>", styles: [".mat-card-avatar-override{height:24px!important;width:24px!important}\n"] }]
        }], propDecorators: { widgetData: [{
                type: Input
            }] } });

class InvalidPermissionComponent extends WidgetBaseComponent {
    constructor() {
        super(...arguments);
        this.showData = true;
    }
    ngOnInit() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: InvalidPermissionComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.16", type: InvalidPermissionComponent, isStandalone: false, selector: "sb-ui-resolver-invalid-permission", inputs: { widgetType: "widgetType", widgetSubType: "widgetSubType", widgetInstanceId: "widgetInstanceId", widgetData: "widgetData" }, usesInheritance: true, ngImport: i0, template: "<mat-card class=\"margin-m\">\n  <mat-card-header>\n    <div mat-card-avatar class=\"mat-card-avatar-override\">\n      <mat-icon color=\"warn\">report_problem</mat-icon>\n    </div>\n    <mat-card-title>\n      <ng-container i18n>\n        Error as Invalid Permission for Widget\n      </ng-container>\n    </mat-card-title>\n  </mat-card-header>\n  <div class=\"flex flex-wrap flex-between\">\n    <div>\n      <div class=\"margin-top-s\">\n        <span class=\"mat-body-2 font-bold\" i18n>\n          Widget Type :\n        </span>\n        {{ widgetType }}\n      </div>\n      <div class=\"margin-top-s\">\n        <span class=\"mat-body-2 font-bold\" i18n>\n          Widget Sub Type :\n        </span>\n        {{ widgetSubType }}\n      </div>\n    </div>\n    <div>\n      <ng-container *ngIf=\"widgetData\">\n        <button mat-raised-button class=\"margin-top-m\" color=\"primary\" *ngIf=\"!showData\" (click)=\"showData = true\">\n          <ng-container i18n>See Details</ng-container>\n          <mat-icon>arrow_drop_down</mat-icon>\n        </button>\n        <button mat-raised-button class=\"margin-top-m\" color=\"primary\" *ngIf=\"showData\" (click)=\"showData = false\">\n          <ng-container i18n>Hide Details</ng-container>\n          <mat-icon>arrow_drop_up</mat-icon>\n        </button>\n      </ng-container>\n    </div>\n  </div>\n  <ng-container *ngIf=\"widgetData\">\n    <pre *ngIf=\"showData\" class=\"margin-top-s \"><span i18n class=\"mat-body-2 font-bold\">Widget Data :</span>\n{{ widgetData | json }}\n    </pre>\n  </ng-container>\n</mat-card>", styles: [".mat-card-avatar-override{height:24px!important;width:24px!important}\n"], dependencies: [{ kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i2.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: i3.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "component", type: i4.MatCard, selector: "mat-card", inputs: ["appearance"], exportAs: ["matCard"] }, { kind: "directive", type: i4.MatCardAvatar, selector: "[mat-card-avatar], [matCardAvatar]" }, { kind: "component", type: i4.MatCardHeader, selector: "mat-card-header" }, { kind: "directive", type: i4.MatCardTitle, selector: "mat-card-title, [mat-card-title], [matCardTitle]" }, { kind: "pipe", type: i1.JsonPipe, name: "json" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: InvalidPermissionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sb-ui-resolver-invalid-permission', standalone: false, template: "<mat-card class=\"margin-m\">\n  <mat-card-header>\n    <div mat-card-avatar class=\"mat-card-avatar-override\">\n      <mat-icon color=\"warn\">report_problem</mat-icon>\n    </div>\n    <mat-card-title>\n      <ng-container i18n>\n        Error as Invalid Permission for Widget\n      </ng-container>\n    </mat-card-title>\n  </mat-card-header>\n  <div class=\"flex flex-wrap flex-between\">\n    <div>\n      <div class=\"margin-top-s\">\n        <span class=\"mat-body-2 font-bold\" i18n>\n          Widget Type :\n        </span>\n        {{ widgetType }}\n      </div>\n      <div class=\"margin-top-s\">\n        <span class=\"mat-body-2 font-bold\" i18n>\n          Widget Sub Type :\n        </span>\n        {{ widgetSubType }}\n      </div>\n    </div>\n    <div>\n      <ng-container *ngIf=\"widgetData\">\n        <button mat-raised-button class=\"margin-top-m\" color=\"primary\" *ngIf=\"!showData\" (click)=\"showData = true\">\n          <ng-container i18n>See Details</ng-container>\n          <mat-icon>arrow_drop_down</mat-icon>\n        </button>\n        <button mat-raised-button class=\"margin-top-m\" color=\"primary\" *ngIf=\"showData\" (click)=\"showData = false\">\n          <ng-container i18n>Hide Details</ng-container>\n          <mat-icon>arrow_drop_up</mat-icon>\n        </button>\n      </ng-container>\n    </div>\n  </div>\n  <ng-container *ngIf=\"widgetData\">\n    <pre *ngIf=\"showData\" class=\"margin-top-s \"><span i18n class=\"mat-body-2 font-bold\">Widget Data :</span>\n{{ widgetData | json }}\n    </pre>\n  </ng-container>\n</mat-card>", styles: [".mat-card-avatar-override{height:24px!important;width:24px!important}\n"] }]
        }], propDecorators: { widgetType: [{
                type: Input
            }], widgetSubType: [{
                type: Input
            }], widgetInstanceId: [{
                type: Input
            }], widgetData: [{
                type: Input
            }] } });

class UnresolvedComponent extends WidgetBaseComponent {
    constructor() {
        super(...arguments);
        this.showData = true;
        this.previewMode = false;
        this.searchArray = ['preview', 'channel'];
    }
    ngOnInit() {
        const url = window.location.href;
        this.previewMode = this.searchArray.some((word) => {
            return url.indexOf(word) > -1;
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: UnresolvedComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.16", type: UnresolvedComponent, isStandalone: false, selector: "sb-ui-resolver-unresolved", inputs: { widgetData: "widgetData" }, usesInheritance: true, ngImport: i0, template: "<ng-container *ngIf=\"previewMode\" [ngTemplateOutlet]=\"previewCardTemplate\"></ng-container>\n<ng-container *ngIf=\"!previewMode\" [ngTemplateOutlet]=\"unresolvedTemplate\"></ng-container>\n\n<ng-template #unresolvedTemplate>\n  <mat-card class=\"margin-m\">\n    <mat-card-header>\n      <div mat-card-avatar class=\"mat-card-avatar-override\">\n        <mat-icon color=\"warn\">report_problem</mat-icon>\n      </div>\n      <mat-card-title>\n        <ng-container i18n>\n          Error in Resolving Json for Widget\n        </ng-container>\n      </mat-card-title>\n    </mat-card-header>\n    <div class=\"flex flex-wrap flex-between\">\n      <div>\n        <div class=\"margin-top-s\">\n          <span class=\"mat-body-2 font-bold\" i18n>\n            Widget Type :\n          </span>\n          {{ widgetType }}\n        </div>\n        <div class=\"margin-top-s\">\n          <span class=\"mat-body-2 font-bold\" i18n>\n            Widget Sub Type :\n          </span>\n          {{ widgetSubType }}\n        </div>\n      </div>\n      <div>\n        <ng-container *ngIf=\"widgetData\">\n          <button mat-raised-button class=\"margin-top-m\" color=\"primary\" *ngIf=\"!showData\" (click)=\"showData = true\">\n            <ng-container i18n>See Details</ng-container>\n            <mat-icon>arrow_drop_down</mat-icon>\n          </button>\n          <button mat-raised-button class=\"margin-top-m\" color=\"primary\" *ngIf=\"showData\" (click)=\"showData = false\">\n            <ng-container i18n>Hide Details</ng-container>\n            <mat-icon>arrow_drop_up</mat-icon>\n          </button>\n        </ng-container>\n      </div>\n    </div>\n    <ng-container *ngIf=\"widgetData\">\n      <pre *ngIf=\"showData\" class=\"margin-top-s\"><span i18n class=\"mat-body-2 font-bold\">Widget Data :</span>\n{{ widgetData | json }}\n    </pre>\n    </ng-container>\n  </mat-card>\n</ng-template>\n<ng-template #previewCardTemplate>\n  <mat-card>\n    <div class=\"w-full\">\n      <div class=\"p-4\">\n        <div class=\"text-3xl font-semibold text-center leading-tight\" i18n>\n          Content not available\n        </div>\n        <br />\n        <div class=\"text-base font-medium text-center leading-normal\" i18n>\n          Please add widget or provide data to widget template\n        </div>\n      </div>\n    </div>\n  </mat-card>\n</ng-template>", styles: [".mat-card-avatar-override{height:24px!important;width:24px!important}\n"], dependencies: [{ kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: i2.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: i3.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "component", type: i4.MatCard, selector: "mat-card", inputs: ["appearance"], exportAs: ["matCard"] }, { kind: "directive", type: i4.MatCardAvatar, selector: "[mat-card-avatar], [matCardAvatar]" }, { kind: "component", type: i4.MatCardHeader, selector: "mat-card-header" }, { kind: "directive", type: i4.MatCardTitle, selector: "mat-card-title, [mat-card-title], [matCardTitle]" }, { kind: "pipe", type: i1.JsonPipe, name: "json" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: UnresolvedComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sb-ui-resolver-unresolved', standalone: false, template: "<ng-container *ngIf=\"previewMode\" [ngTemplateOutlet]=\"previewCardTemplate\"></ng-container>\n<ng-container *ngIf=\"!previewMode\" [ngTemplateOutlet]=\"unresolvedTemplate\"></ng-container>\n\n<ng-template #unresolvedTemplate>\n  <mat-card class=\"margin-m\">\n    <mat-card-header>\n      <div mat-card-avatar class=\"mat-card-avatar-override\">\n        <mat-icon color=\"warn\">report_problem</mat-icon>\n      </div>\n      <mat-card-title>\n        <ng-container i18n>\n          Error in Resolving Json for Widget\n        </ng-container>\n      </mat-card-title>\n    </mat-card-header>\n    <div class=\"flex flex-wrap flex-between\">\n      <div>\n        <div class=\"margin-top-s\">\n          <span class=\"mat-body-2 font-bold\" i18n>\n            Widget Type :\n          </span>\n          {{ widgetType }}\n        </div>\n        <div class=\"margin-top-s\">\n          <span class=\"mat-body-2 font-bold\" i18n>\n            Widget Sub Type :\n          </span>\n          {{ widgetSubType }}\n        </div>\n      </div>\n      <div>\n        <ng-container *ngIf=\"widgetData\">\n          <button mat-raised-button class=\"margin-top-m\" color=\"primary\" *ngIf=\"!showData\" (click)=\"showData = true\">\n            <ng-container i18n>See Details</ng-container>\n            <mat-icon>arrow_drop_down</mat-icon>\n          </button>\n          <button mat-raised-button class=\"margin-top-m\" color=\"primary\" *ngIf=\"showData\" (click)=\"showData = false\">\n            <ng-container i18n>Hide Details</ng-container>\n            <mat-icon>arrow_drop_up</mat-icon>\n          </button>\n        </ng-container>\n      </div>\n    </div>\n    <ng-container *ngIf=\"widgetData\">\n      <pre *ngIf=\"showData\" class=\"margin-top-s\"><span i18n class=\"mat-body-2 font-bold\">Widget Data :</span>\n{{ widgetData | json }}\n    </pre>\n    </ng-container>\n  </mat-card>\n</ng-template>\n<ng-template #previewCardTemplate>\n  <mat-card>\n    <div class=\"w-full\">\n      <div class=\"p-4\">\n        <div class=\"text-3xl font-semibold text-center leading-tight\" i18n>\n          Content not available\n        </div>\n        <br />\n        <div class=\"text-base font-medium text-center leading-normal\" i18n>\n          Please add widget or provide data to widget template\n        </div>\n      </div>\n    </div>\n  </mat-card>\n</ng-template>", styles: [".mat-card-avatar-override{height:24px!important;width:24px!important}\n"] }]
        }], propDecorators: { widgetData: [{
                type: Input
            }] } });

class SbUiResolverService {
    constructor(domSanitizer, componentFactoryResolver, 
    // private loggerSvc: LoggerService,
    globalConfig, scopedConfig) {
        this.domSanitizer = domSanitizer;
        this.componentFactoryResolver = componentFactoryResolver;
        this.globalConfig = globalConfig;
        this.scopedConfig = scopedConfig;
        this.roles = null;
        this.groups = null;
        this.restrictedFeatures = null;
        this.isInitialized = false;
        this.availableRegisteredWidgets = null;
        this.restrictedWidgetKeys = null;
    }
    static getWidgetKey(config) {
        return `widget:${config.widgetType}::${config.widgetSubType}`;
    }
    initialize(restrictedWidgetKeys, roles, groups, restrictedFeatures) {
        this.roles = roles;
        this.groups = groups;
        this.restrictedFeatures = restrictedFeatures;
        const restrictedWidgetKeysSet = restrictedWidgetKeys
            ? restrictedWidgetKeys
            : new Set();
        const registrationConfig = new Map();
        const allWidgetsConfigurations = [];
        if (this.globalConfig && Array.isArray(this.globalConfig)) {
            allWidgetsConfigurations.push(...this.globalConfig);
        }
        if (this.scopedConfig && Array.isArray(this.scopedConfig)) {
            allWidgetsConfigurations.push(...this.scopedConfig);
        }
        allWidgetsConfigurations.forEach(u => {
            const key = SbUiResolverService.getWidgetKey(u);
            if (!restrictedWidgetKeysSet.has(key)) {
                registrationConfig.set(key, u);
            }
        });
        this.restrictedWidgetKeys = restrictedWidgetKeysSet;
        this.availableRegisteredWidgets = registrationConfig;
        this.isInitialized = true;
        // this.loggerSvc.log(
        //   `Widget Configurations`,
        //   this.globalConfig,
        //   this.scopedConfig,
        //   this.availableRegisteredWidgets,
        // )
    }
    resolveWidget(receivedConfig, containerRef) {
        const key = SbUiResolverService.getWidgetKey(receivedConfig);
        if (this.restrictedWidgetKeys && this.restrictedWidgetKeys.has(key)) {
            // Restricted
            return this.widgetResolved(containerRef, receivedConfig, RestrictedComponent);
        }
        if (this.availableRegisteredWidgets && this.availableRegisteredWidgets.has(key)) {
            if (hasPermissions(receivedConfig.widgetPermission, this.roles, this.groups, this.restrictedFeatures)) {
                const config = this.availableRegisteredWidgets.get(key);
                if (config && config.component) {
                    return this.widgetResolved(containerRef, receivedConfig, config.component);
                }
                // Not properly registered
                return this.widgetResolved(containerRef, receivedConfig, InvalidRegistrationComponent);
            }
            // No Permission
            return this.widgetResolved(containerRef, receivedConfig, InvalidPermissionComponent);
        }
        // Not Resolved
        return this.widgetResolved(containerRef, receivedConfig, UnresolvedComponent);
    }
    widgetResolved(containerRef, compData, component) {
        const factory = this.componentFactoryResolver.resolveComponentFactory(component);
        containerRef.clear();
        const compRef = containerRef.createComponent(factory);
        compRef.instance.widgetData = compData.widgetData;
        if (compRef.instance.updateBaseComponent) {
            const widgetSafeStyle = compData.widgetHostStyle
                ? this.domSanitizer.bypassSecurityTrustStyle(Object.entries(compData.widgetHostStyle).reduce((s, [k, v]) => `${s}${k}:${v};`, ''))
                : undefined;
            compRef.instance.updateBaseComponent(compData.widgetType, compData.widgetSubType, compData.widgetInstanceId, compData.widgetHostClass, widgetSafeStyle);
        }
        return compRef;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: SbUiResolverService, deps: [{ token: i1$1.DomSanitizer }, { token: i0.ComponentFactoryResolver }, { token: WIDGET_RESOLVER_GLOBAL_CONFIG }, { token: WIDGET_RESOLVER_SCOPED_CONFIG }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: SbUiResolverService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: SbUiResolverService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1$1.DomSanitizer }, { type: i0.ComponentFactoryResolver }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [WIDGET_RESOLVER_GLOBAL_CONFIG]
                }] }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [WIDGET_RESOLVER_SCOPED_CONFIG]
                }] }] });

class SbUiResolverDirective {
    constructor(viewContainerRef, widgetResolverSvc, logger) {
        this.viewContainerRef = viewContainerRef;
        this.widgetResolverSvc = widgetResolverSvc;
        this.logger = logger;
        this.sbUiResolverWidget = null;
    }
    ngOnChanges() {
        if (!this.widgetResolverSvc.isInitialized) {
            this.logger.error('Widgets Registration Not Done. Used Before Initialization.', this.sbUiResolverWidget);
            return;
        }
        if (this.sbUiResolverWidget) {
            const compRef = this.widgetResolverSvc.resolveWidget(this.sbUiResolverWidget, this.viewContainerRef);
            if (compRef) {
                compRef.changeDetectorRef.detectChanges();
            }
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: SbUiResolverDirective, deps: [{ token: i0.ViewContainerRef }, { token: SbUiResolverService }, { token: i2$1.LoggerService }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.16", type: SbUiResolverDirective, isStandalone: false, selector: "[sbUiResolverWidget]", inputs: { sbUiResolverWidget: "sbUiResolverWidget" }, usesOnChanges: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: SbUiResolverDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[sbUiResolverWidget]',
                    standalone: false
                }]
        }], ctorParameters: () => [{ type: i0.ViewContainerRef }, { type: SbUiResolverService }, { type: i2$1.LoggerService }], propDecorators: { sbUiResolverWidget: [{
                type: Input
            }] } });

class SbUiResolverModule {
    static forRoot(config) {
        return {
            ngModule: SbUiResolverModule,
            providers: [
                SbUiResolverService,
                {
                    provide: WIDGET_RESOLVER_GLOBAL_CONFIG,
                    useValue: config,
                },
                {
                    provide: WIDGET_RESOLVER_SCOPED_CONFIG,
                    useValue: [],
                },
            ],
        };
    }
    static forChild(config) {
        return {
            ngModule: SbUiResolverModule,
            providers: [
                SbUiResolverService,
                {
                    provide: WIDGET_RESOLVER_SCOPED_CONFIG,
                    useValue: config,
                },
            ],
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: SbUiResolverModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.16", ngImport: i0, type: SbUiResolverModule, declarations: [WidgetBaseComponent,
            SbUiResolverDirective,
            RestrictedComponent,
            InvalidRegistrationComponent,
            InvalidPermissionComponent,
            UnresolvedComponent], imports: [CommonModule, MatButtonModule, MatIconModule, MatCardModule], exports: [SbUiResolverDirective, WidgetBaseComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: SbUiResolverModule, imports: [CommonModule, MatButtonModule, MatIconModule, MatCardModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: SbUiResolverModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        WidgetBaseComponent,
                        SbUiResolverDirective,
                        RestrictedComponent,
                        InvalidRegistrationComponent,
                        InvalidPermissionComponent,
                        UnresolvedComponent,
                    ],
                    imports: [CommonModule, MatButtonModule, MatIconModule, MatCardModule],
                    exports: [SbUiResolverDirective, WidgetBaseComponent]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { SbUiResolverDirective, SbUiResolverModule, SbUiResolverService, WidgetBaseComponent, hasPermissions, hasUnitPermission };
//# sourceMappingURL=sunbird-cb-resolver-v2.mjs.map
